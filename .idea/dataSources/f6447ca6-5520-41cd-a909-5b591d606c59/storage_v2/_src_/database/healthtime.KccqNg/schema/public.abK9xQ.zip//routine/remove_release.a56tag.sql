create function remove_release()
  returns trigger
language plpgsql
as $$
BEGIN
UPDATE appointment_release
    SET id_appointment = NEW.id_appointment
    WHERE id_specialty = NEW.id_specialty
      AND id_appointment = NULL
      AND id_patient = NEW.id_consultant;
RETURN NEW;
END;
$$;

alter function remove_release()
  owner to postgres;

