create function available_appointments(consultant integer, city integer, search_day date DEFAULT now(), specialty integer DEFAULT 1)
  returns TABLE(appointment_time dmn_appointment_time, week_day double precision, id_doctor integer)
language sql
as $$
SELECT DISTINCT
                wt.appointment_time,
                wt.week_day,
                wt.id_doctor
FROM working_time AS wt
       JOIN doctor AS d ON wt.id_doctor = d.id_user
       JOIN doctor_specialty AS ds ON d.id_user = ds.id_doctor
WHERE ds.id_specialty = specialty
  AND wt.id_city = city
  AND wt.week_day = extract(ISODOW FROM search_day)
  AND wt.appointment_time NOT IN (
    SELECT appointment_time
      FROM appointment
      WHERE id_consultant = consultant
        AND appointment_date = search_day
    )

    EXCEPT

SELECT
       a.appointment_time,
       extract(ISODOW FROM a.appointment_date) AS week_day,
       a.id_doctor
FROM appointment AS a
WHERE a.id_city = city
  AND a.appointment_date = search_day
ORDER BY appointment_time
$$;

alter function available_appointments(integer, integer, date, integer)
  owner to postgres;

