create function update_release()
  returns trigger
language plpgsql
as $$
BEGIN

IF TG_OP = 'DELETE' THEN 
  UPDATE appointment_release
    SET id_appointment = NULL
    WHERE id_appointment = OLD.id_appointment;
END IF;

IF TG_OP = 'INSERT' AND NEW.id_specialty != 1 THEN
  UPDATE appointment_release
    SET id_appointment = NEW.id_appointment
    WHERE id_specialty = NEW.id_specialty
      AND id_appointment = NULL;
END IF;

RETURN NEW;
END;
$$;

alter function update_release()
  owner to postgres;

