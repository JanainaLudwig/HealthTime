create function set_appointment_on_release()
  returns trigger
language plpgsql
as $$
BEGIN
UPDATE appointment_release
    SET id_appointment = NEW.id_appointment
    WHERE id_specialty = NEW.id_specialty
      AND id_appointment IS NULL
      AND id_patient = NEW.id_consultant
      AND release_date = (
        SELECT max(release_date) FROM appointment_release
          WHERE id_specialty = NEW.id_specialty
            AND id_appointment IS NULL
            AND id_patient = NEW.id_consultant
      );
RETURN NULL;
END;
$$;

alter function set_appointment_on_release()
  owner to postgres;

